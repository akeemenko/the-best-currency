package com.example.thebestcurrency.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.thebestcurrency.R

class CurrenciesListFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // раздуть макет для этого фрагмента
        return inflater.inflate(R.layout.fragment_currencies_list, container, false)
    }

}
